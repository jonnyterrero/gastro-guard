"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Activity,
  BarChart3,
  Calendar,
  Download,
  Heart,
  PlusCircle,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Utensils,
} from "lucide-react"

// Types
interface LogEntry {
  id: string
  time: string
  meal: string
  painLevel: number
  stressLevel: number
  remedy: string
}

interface FilterPeriod {
  label: string
  value: string
  days?: number
}

const filterPeriods: FilterPeriod[] = [
  { label: "All", value: "all" },
  { label: "Today", value: "today", days: 0 },
  { label: "Last 7 Days", value: "7days", days: 7 },
  { label: "Last 30 Days", value: "30days", days: 30 },
  { label: "This Month", value: "month" },
]

export default function GastroGuardApp() {
  const [logData, setLogData] = useState<LogEntry[]>([])
  const [activeTab, setActiveTab] = useState("dashboard")
  const [currentFilter, setCurrentFilter] = useState("all")
  const [filteredData, setFilteredData] = useState<LogEntry[]>([])

  // Form states
  const [meal, setMeal] = useState("")
  const [painLevel, setPainLevel] = useState([5])
  const [stressLevel, setStressLevel] = useState([5])
  const [remedy, setRemedy] = useState("")
  const [showSuccess, setShowSuccess] = useState(false)

  // Load data from localStorage on mount
  useEffect(() => {
    const savedData = localStorage.getItem("gastroguard-data")
    if (savedData) {
      setLogData(JSON.parse(savedData))
    }
  }, [])

  // Save data to localStorage whenever logData changes
  useEffect(() => {
    localStorage.setItem("gastroguard-data", JSON.stringify(logData))
    filterData(currentFilter)
  }, [logData, currentFilter])

  // Filter data based on selected period
  const filterData = (period: string) => {
    const now = new Date()
    let filtered = logData

    switch (period) {
      case "today":
        const today = now.toDateString()
        filtered = logData.filter((entry) => new Date(entry.time).toDateString() === today)
        break
      case "7days":
        const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
        filtered = logData.filter((entry) => new Date(entry.time) >= sevenDaysAgo)
        break
      case "30days":
        const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
        filtered = logData.filter((entry) => new Date(entry.time) >= thirtyDaysAgo)
        break
      case "month":
        const monthStart = new Date(now.getFullYear(), now.getMonth(), 1)
        filtered = logData.filter((entry) => new Date(entry.time) >= monthStart)
        break
      default:
        filtered = logData
    }

    setFilteredData(filtered)
    setCurrentFilter(period)
  }

  // Submit new log entry
  const submitEntry = () => {
    if (!meal.trim() || !remedy.trim()) return

    const newEntry: LogEntry = {
      id: Date.now().toString(),
      time: new Date().toISOString(),
      meal: meal.trim(),
      painLevel: painLevel[0],
      stressLevel: stressLevel[0],
      remedy: remedy.trim(),
    }

    setLogData((prev) => [newEntry, ...prev])

    // Reset form
    setMeal("")
    setPainLevel([5])
    setStressLevel([5])
    setRemedy("")

    // Show success message
    setShowSuccess(true)
    setTimeout(() => setShowSuccess(false), 3000)
  }

  // Calculate statistics
  const stats = {
    totalEntries: filteredData.length,
    avgPain:
      filteredData.length > 0
        ? (filteredData.reduce((sum, entry) => sum + entry.painLevel, 0) / filteredData.length).toFixed(1)
        : "0",
    avgStress:
      filteredData.length > 0
        ? (filteredData.reduce((sum, entry) => sum + entry.stressLevel, 0) / filteredData.length).toFixed(1)
        : "0",
    uniqueFoods: new Set(filteredData.map((entry) => entry.meal)).size,
  }

  // Analyze food triggers
  const analyzeFoodTriggers = () => {
    const foodMap = new Map<string, { totalPain: number; count: number; avgPain: number }>()

    filteredData.forEach((entry) => {
      const existing = foodMap.get(entry.meal) || { totalPain: 0, count: 0, avgPain: 0 }
      existing.totalPain += entry.painLevel
      existing.count += 1
      existing.avgPain = existing.totalPain / existing.count
      foodMap.set(entry.meal, existing)
    })

    return Array.from(foodMap.entries())
      .map(([food, data]) => ({ food, ...data }))
      .sort((a, b) => b.avgPain - a.avgPain)
      .slice(0, 5)
  }

  // Analyze remedy effectiveness
  const analyzeRemedyEffectiveness = () => {
    const remedyMap = new Map<string, { totalPain: number; count: number; avgPain: number }>()

    filteredData.forEach((entry) => {
      const existing = remedyMap.get(entry.remedy) || { totalPain: 0, count: 0, avgPain: 0 }
      existing.totalPain += entry.painLevel
      existing.count += 1
      existing.avgPain = existing.totalPain / existing.count
      remedyMap.set(entry.remedy, existing)
    })

    return Array.from(remedyMap.entries())
      .map(([remedy, data]) => ({ remedy, ...data }))
      .sort((a, b) => a.avgPain - b.avgPain)
      .slice(0, 5)
  }

  // Export data as CSV
  const exportData = () => {
    const headers = ["Time", "Meal", "Pain Level", "Stress Level", "Remedy"]
    const csvContent = [
      headers.join(","),
      ...filteredData.map((entry) =>
        [entry.time, `"${entry.meal}"`, entry.painLevel, entry.stressLevel, `"${entry.remedy}"`].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `gastroguard-data-${new Date().toISOString().split("T")[0]}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  const foodTriggers = analyzeFoodTriggers()
  const remedyEffectiveness = analyzeRemedyEffectiveness()

  return (
    <div className="min-h-screen bg-gradient-to-br from-secondary/30 to-background">
      <div className="container mx-auto px-4 py-6 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="font-heading font-black text-4xl md:text-5xl text-primary mb-2">🏥 GastroGuard</h1>
          <p className="text-lg text-muted-foreground font-medium">Your Health, Your Journey</p>
        </div>

        {/* Success Alert */}
        {showSuccess && (
          <Alert className="mb-6 border-green-200 bg-green-50 text-green-800">
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>Entry logged successfully! Keep tracking your progress.</AlertDescription>
          </Alert>
        )}

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 lg:grid-cols-6 h-auto p-1">
            <TabsTrigger value="dashboard" className="flex items-center gap-2 py-3">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">Dashboard</span>
            </TabsTrigger>
            <TabsTrigger value="log" className="flex items-center gap-2 py-3">
              <PlusCircle className="h-4 w-4" />
              <span className="hidden sm:inline">Log Entry</span>
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2 py-3">
              <TrendingUp className="h-4 w-4" />
              <span className="hidden sm:inline">Analytics</span>
            </TabsTrigger>
            <TabsTrigger value="triggers" className="flex items-center gap-2 py-3">
              <AlertTriangle className="h-4 w-4" />
              <span className="hidden sm:inline">Triggers</span>
            </TabsTrigger>
            <TabsTrigger value="simulation" className="flex items-center gap-2 py-3">
              <Activity className="h-4 w-4" />
              <span className="hidden sm:inline">Simulation</span>
            </TabsTrigger>
            <TabsTrigger value="export" className="flex items-center gap-2 py-3">
              <Download className="h-4 w-4" />
              <span className="hidden sm:inline">Export</span>
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            {/* Filter Buttons */}
            <Card>
              <CardHeader>
                <CardTitle className="font-heading flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Time Filters
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {filterPeriods.map((period) => (
                    <Button
                      key={period.value}
                      variant={currentFilter === period.value ? "default" : "outline"}
                      onClick={() => filterData(period.value)}
                      className="transition-all duration-200"
                    >
                      {period.label}
                    </Button>
                  ))}
                </div>
                <div className="mt-4 text-sm text-muted-foreground">
                  Showing:{" "}
                  <Badge variant="secondary">{filterPeriods.find((p) => p.value === currentFilter)?.label}</Badge>
                  {filteredData.length > 0 && <span className="ml-2">• {filteredData.length} entries</span>}
                </div>
              </CardContent>
            </Card>

            {/* Stats Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Heart className="h-5 w-5 text-primary" />
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Total Entries</p>
                      <p className="text-2xl font-bold text-primary">{stats.totalEntries}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-destructive/5 to-destructive/10 border-destructive/20">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-destructive" />
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Avg Pain</p>
                      <p className="text-2xl font-bold text-destructive">{stats.avgPain}/10</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-accent/5 to-accent/10 border-accent/20">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Activity className="h-5 w-5 text-accent" />
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Avg Stress</p>
                      <p className="text-2xl font-bold text-accent">{stats.avgStress}/10</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-green-500/5 to-green-500/10 border-green-500/20">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Utensils className="h-5 w-5 text-green-600" />
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Unique Foods</p>
                      <p className="text-2xl font-bold text-green-600">{stats.uniqueFoods}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Entries */}
            {filteredData.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="font-heading">Recent Entries</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {filteredData.slice(0, 5).map((entry) => (
                      <div key={entry.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div className="flex-1">
                          <p className="font-medium">{entry.meal}</p>
                          <p className="text-sm text-muted-foreground">
                            {new Date(entry.time).toLocaleDateString()} • {entry.remedy}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <Badge
                            variant={
                              entry.painLevel > 6 ? "destructive" : entry.painLevel > 3 ? "secondary" : "default"
                            }
                          >
                            Pain: {entry.painLevel}
                          </Badge>
                          <Badge variant="outline">Stress: {entry.stressLevel}</Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {filteredData.length === 0 && (
              <Card>
                <CardContent className="text-center py-12">
                  <Heart className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-heading text-lg font-semibold mb-2">No entries yet</h3>
                  <p className="text-muted-foreground mb-4">Start tracking your symptoms to see insights here</p>
                  <Button onClick={() => setActiveTab("log")}>
                    <PlusCircle className="h-4 w-4 mr-2" />
                    Log Your First Entry
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Log Entry Tab */}
          <TabsContent value="log" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="font-heading">Track Your Symptoms with Ease</CardTitle>
                <CardDescription>
                  Log your meal, pain level, stress, and remedy to build your health profile
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="meal" className="font-medium">
                      Meal/Food Consumed
                    </Label>
                    <Input
                      id="meal"
                      placeholder="e.g., Pizza, Coffee, Salad..."
                      value={meal}
                      onChange={(e) => setMeal(e.target.value)}
                      className="h-12"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="remedy" className="font-medium">
                      Remedy Used
                    </Label>
                    <Input
                      id="remedy"
                      placeholder="e.g., Antacid, Rest, Water..."
                      value={remedy}
                      onChange={(e) => setRemedy(e.target.value)}
                      className="h-12"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <Label className="font-medium">Pain Level: {painLevel[0]}/10</Label>
                    <Slider value={painLevel} onValueChange={setPainLevel} max={10} step={1} className="w-full" />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>No pain</span>
                      <span>Severe pain</span>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <Label className="font-medium">Stress Level: {stressLevel[0]}/10</Label>
                    <Slider value={stressLevel} onValueChange={setStressLevel} max={10} step={1} className="w-full" />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>No stress</span>
                      <span>High stress</span>
                    </div>
                  </div>
                </div>

                <Button
                  onClick={submitEntry}
                  disabled={!meal.trim() || !remedy.trim()}
                  className="w-full h-12 text-lg font-semibold"
                  size="lg"
                >
                  <PlusCircle className="h-5 w-5 mr-2" />
                  Log Entry
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            {filteredData.length === 0 ? (
              <Card>
                <CardContent className="text-center py-12">
                  <TrendingUp className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-heading text-lg font-semibold mb-2">No data to analyze</h3>
                  <p className="text-muted-foreground">Log some entries to see detailed analytics</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="font-heading">Pain Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {[...Array(11)].map((_, i) => {
                        const count = filteredData.filter((entry) => entry.painLevel === i).length
                        const percentage = filteredData.length > 0 ? (count / filteredData.length) * 100 : 0
                        return (
                          <div key={i} className="flex items-center gap-3">
                            <span className="w-8 text-sm font-medium">{i}/10</span>
                            <div className="flex-1 bg-muted rounded-full h-2">
                              <div
                                className="bg-primary h-2 rounded-full transition-all duration-300"
                                style={{ width: `${percentage}%` }}
                              />
                            </div>
                            <span className="w-8 text-sm text-muted-foreground">{count}</span>
                          </div>
                        )
                      })}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="font-heading">Time Analysis</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-semibold mb-2">Peak Pain Times</h4>
                        {filteredData.length > 0 &&
                          (() => {
                            const hourlyPain = new Map<number, { total: number; count: number }>()
                            filteredData.forEach((entry) => {
                              const hour = new Date(entry.time).getHours()
                              const existing = hourlyPain.get(hour) || { total: 0, count: 0 }
                              existing.total += entry.painLevel
                              existing.count += 1
                              hourlyPain.set(hour, existing)
                            })

                            const sortedHours = Array.from(hourlyPain.entries())
                              .map(([hour, data]) => ({ hour, avg: data.total / data.count }))
                              .sort((a, b) => b.avg - a.avg)
                              .slice(0, 3)

                            return (
                              <div className="space-y-2">
                                {sortedHours.map(({ hour, avg }, index) => (
                                  <div key={hour} className="flex justify-between items-center">
                                    <span className="text-sm">
                                      {hour}:00 - {hour + 1}:00
                                    </span>
                                    <Badge variant={index === 0 ? "destructive" : "secondary"}>
                                      {avg.toFixed(1)} avg
                                    </Badge>
                                  </div>
                                ))}
                              </div>
                            )
                          })()}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          {/* Triggers Tab */}
          <TabsContent value="triggers" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="font-heading text-destructive">Discover Your Triggers</CardTitle>
                  <CardDescription>Foods that cause the highest pain levels</CardDescription>
                </CardHeader>
                <CardContent>
                  {foodTriggers.length > 0 ? (
                    <div className="space-y-3">
                      {foodTriggers.map((trigger, index) => (
                        <div
                          key={trigger.food}
                          className="flex items-center justify-between p-3 bg-destructive/5 rounded-lg border border-destructive/20"
                        >
                          <div>
                            <p className="font-medium">{trigger.food}</p>
                            <p className="text-sm text-muted-foreground">{trigger.count} entries</p>
                          </div>
                          <Badge variant="destructive">{trigger.avgPain.toFixed(1)}/10</Badge>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground text-center py-8">No data available for trigger analysis</p>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="font-heading text-green-600">Assess What Works for You</CardTitle>
                  <CardDescription>Most effective remedies (lowest pain levels)</CardDescription>
                </CardHeader>
                <CardContent>
                  {remedyEffectiveness.length > 0 ? (
                    <div className="space-y-3">
                      {remedyEffectiveness.map((remedy, index) => (
                        <div
                          key={remedy.remedy}
                          className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200"
                        >
                          <div>
                            <p className="font-medium">{remedy.remedy}</p>
                            <p className="text-sm text-muted-foreground">{remedy.count} uses</p>
                          </div>
                          <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                            {remedy.avgPain.toFixed(1)}/10
                          </Badge>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground text-center py-8">No data available for remedy analysis</p>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Recommendations */}
            {(foodTriggers.length > 0 || remedyEffectiveness.length > 0) && (
              <Card>
                <CardHeader>
                  <CardTitle className="font-heading">💡 Personalized Recommendations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {foodTriggers.length > 0 && (
                      <Alert className="border-destructive/20 bg-destructive/5">
                        <AlertTriangle className="h-4 w-4" />
                        <AlertDescription>
                          <strong>Consider avoiding:</strong> {foodTriggers[0].food} (highest pain trigger with{" "}
                          {foodTriggers[0].avgPain.toFixed(1)}/10 average pain)
                        </AlertDescription>
                      </Alert>
                    )}

                    {remedyEffectiveness.length > 0 && (
                      <Alert className="border-green-200 bg-green-50">
                        <CheckCircle className="h-4 w-4" />
                        <AlertDescription>
                          <strong>Most effective remedy:</strong> {remedyEffectiveness[0].remedy} (lowest pain levels at{" "}
                          {remedyEffectiveness[0].avgPain.toFixed(1)}/10 average)
                        </AlertDescription>
                      </Alert>
                    )}

                    {Number.parseFloat(stats.avgPain) > 6 && (
                      <Alert>
                        <Heart className="h-4 w-4" />
                        <AlertDescription>
                          Your average pain level is high ({stats.avgPain}/10). Consider consulting with a healthcare
                          provider.
                        </AlertDescription>
                      </Alert>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Simulation Tab */}
          <TabsContent value="simulation" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="font-heading">🧪 Symptom Prediction</CardTitle>
                <CardDescription>
                  Predict gastritis symptoms based on your current stress and eating patterns
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Alert>
                  <Activity className="h-4 w-4" />
                  <AlertDescription>
                    This simulation uses mathematical modeling to predict symptom severity. Results are for
                    informational purposes only and should not replace medical advice.
                  </AlertDescription>
                </Alert>

                <div className="mt-6 text-center py-12 text-muted-foreground">
                  <Activity className="h-12 w-12 mx-auto mb-4" />
                  <p>Advanced simulation feature coming soon!</p>
                  <p className="text-sm mt-2">Will include stress-based symptom prediction and timeline modeling</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Export Tab */}
          <TabsContent value="export" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="font-heading">📋 Export Your Data</CardTitle>
                <CardDescription>
                  Download your health data to share with healthcare providers or for personal records
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-muted/50 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">Export Summary</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Filter:</span>
                      <Badge variant="secondary" className="ml-2">
                        {filterPeriods.find((p) => p.value === currentFilter)?.label}
                      </Badge>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Records:</span>
                      <span className="ml-2 font-medium">{filteredData.length}</span>
                    </div>
                  </div>
                </div>

                {filteredData.length > 0 ? (
                  <>
                    <Button onClick={exportData} className="w-full" size="lg">
                      <Download className="h-5 w-5 mr-2" />
                      Download CSV File
                    </Button>

                    <div className="text-sm text-muted-foreground space-y-1">
                      <p>• CSV file includes: Time, Meal, Pain Level, Stress Level, Remedy</p>
                      <p>• Compatible with Excel, Google Sheets, and medical software</p>
                      <p>• Data is filtered based on your current time selection</p>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8">
                    <Download className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">No data available to export</p>
                    <p className="text-sm text-muted-foreground mt-2">
                      Log some entries first, then return here to download your data
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
